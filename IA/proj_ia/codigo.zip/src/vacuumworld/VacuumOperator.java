package vacuumworld;

public enum VacuumOperator {
	LEFT, RIGHT, SUCK
}
