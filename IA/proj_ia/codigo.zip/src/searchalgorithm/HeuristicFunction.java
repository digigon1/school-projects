package searchalgorithm;

public interface HeuristicFunction {
	public double heuristic(Node n);
}
